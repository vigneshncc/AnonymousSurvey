# hackathonVBI
# Blockchain Survey
Blockchain survey allows user to take completely anonymous survey.

# Technologies used
Blockchain
Ethereum Smart Contracts
